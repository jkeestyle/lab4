package com.example.randomgallery.spacexdataviewer.model;


public interface Cancellable {

    void cancel();
}
