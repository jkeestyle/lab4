package com.example.randomgallery.spacexdataviewer.logger;

public interface Logger {

    void e(Throwable e);
}
